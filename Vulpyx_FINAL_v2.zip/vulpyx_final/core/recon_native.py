"""
VULPYX – Native Parallel Recon Engine
Pure Python recon — NO subprocess, NO Ollama during scanning.
All heavy modules run in parallel threads.
Logic from: omnisci3nt + HuntTheBug
"""
import os
import sys
import ssl
import socket
import asyncio
import threading
import re
import json
import time
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse, urljoin

# Optional imports — graceful fallback if not installed
try:
    import dns.resolver
    DNS_OK = True
except ImportError:
    DNS_OK = False

try:
    from bs4 import BeautifulSoup
    BS4_OK = True
except ImportError:
    BS4_OK = False

try:
    import aiohttp
    AIOHTTP_OK = True
except ImportError:
    AIOHTTP_OK = False

from core.banner import (
    GRN, YEL, CYN, RED, MGN, WHT, DIM, R, BLD,
    print_info, print_ok, print_warn, _tw
)
from core.utils import ensure_dir, save_file

# ── Constants ──────────────────────────────────────────────────────────────────
UA = "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0"
HEADERS = {"User-Agent": UA}
REQUEST_TIMEOUT = 8
PORT_TIMEOUT    = 1
SEM_LIMIT       = 300   # async port scan concurrency

TOP_PORTS = [
    21,22,23,25,53,80,110,111,135,139,143,443,445,
    993,995,1723,3306,3389,5900,8080,8443,8888,
    9200,27017,6379,5432,1521,1433,2049,161
]


# ══════════════════════════════════════════════════════════════════════════════
#  INDIVIDUAL RECON MODULES
# ══════════════════════════════════════════════════════════════════════════════

def mod_dns(target: str) -> dict:
    """DNS enumeration — A, AAAA, MX, NS, TXT, CNAME, DMARC"""
    result = {"name": "DNS", "lines": [], "status": "ok"}
    if not DNS_OK:
        result["status"] = "skip"
        result["lines"] = ["[SKIP] dnspython not installed"]
        return result
    try:
        ip = socket.gethostbyname(target)
        result["lines"].append(f"IP: {ip}")
    except Exception as e:
        result["lines"].append(f"[!] Could not resolve: {e}")
        result["status"] = "fail"
        return result

    resolver = dns.resolver.Resolver()
    resolver.nameservers = ["8.8.8.8", "1.1.1.1"]
    resolver.timeout = 3
    resolver.lifetime = 3

    for rtype in ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "CAA"]:
        try:
            answers = resolver.resolve(target, rtype)
            for ans in answers:
                result["lines"].append(f"{rtype}: {ans}")
        except Exception:
            pass

    # DMARC
    try:
        answers = resolver.resolve(f"_dmarc.{target}", "TXT")
        for ans in answers:
            result["lines"].append(f"DMARC: {ans}")
    except Exception:
        pass

    # SPF check
    try:
        answers = resolver.resolve(target, "TXT")
        for ans in answers:
            txt = str(ans)
            if "v=spf1" in txt:
                result["lines"].append(f"SPF: {txt}")
    except Exception:
        pass

    return result


def mod_ports(target: str) -> dict:
    """Async port scanner — scans top ports fast"""
    result = {"name": "PORTSCAN", "lines": [], "status": "ok"}

    try:
        ip = socket.gethostbyname(target)
    except Exception as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] Cannot resolve: {e}"]
        return result

    open_ports = []

    async def _scan_port(sem, ip, port):
        async with sem:
            try:
                _, writer = await asyncio.wait_for(
                    asyncio.open_connection(ip, port), timeout=PORT_TIMEOUT
                )
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass
                open_ports.append(port)
            except Exception:
                pass

    async def _run():
        sem = asyncio.Semaphore(SEM_LIMIT)
        tasks = [_scan_port(sem, ip, p) for p in TOP_PORTS]
        await asyncio.gather(*tasks, return_exceptions=True)

    try:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(_run())
        loop.close()
    except Exception as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] Port scan error: {e}"]
        return result

    for port in sorted(open_ports):
        try:
            svc = socket.getservbyport(port)
        except Exception:
            svc = "unknown"
        result["lines"].append(f"{port}/tcp  open  {svc}")

    if not open_ports:
        result["lines"].append("No open ports found in top port list")
    else:
        result["lines"].append(f"Total open: {len(open_ports)}")

    return result


def mod_headers(target: str) -> dict:
    """HTTP headers + security header analysis"""
    result = {"name": "HEADERS", "lines": [], "status": "ok"}
    for scheme in ["https", "http"]:
        try:
            url = f"{scheme}://{target}"
            r = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT,
                             verify=False, allow_redirects=True)
            result["lines"].append(f"URL: {r.url}")
            result["lines"].append(f"Status: {r.status_code}")
            for k, v in r.headers.items():
                result["lines"].append(f"{k}: {v}")

            # Security header audit
            sec = ["Content-Security-Policy","Strict-Transport-Security",
                   "X-Frame-Options","X-Content-Type-Options",
                   "Referrer-Policy","Permissions-Policy"]
            missing = [h for h in sec if h not in r.headers]
            if missing:
                result["lines"].append(f"[!] Missing security headers: {', '.join(missing)}")
            return result
        except Exception:
            continue

    result["status"] = "fail"
    result["lines"] = ["[!] Could not connect"]
    return result


def mod_ssl(target: str) -> dict:
    """SSL certificate inspection"""
    result = {"name": "SSL", "lines": [], "status": "ok"}
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((target, 443), timeout=REQUEST_TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=target) as ssock:
                cert = ssock.getpeercert()
                result["lines"].append(f"Subject: {dict(x[0] for x in cert.get('subject', []))}")
                result["lines"].append(f"Issuer: {dict(x[0] for x in cert.get('issuer', []))}")
                result["lines"].append(f"Valid From: {cert.get('notBefore')}")
                result["lines"].append(f"Valid Until: {cert.get('notAfter')}")
                sans = [v for t, v in cert.get('subjectAltName', []) if t == 'DNS']
                if sans:
                    result["lines"].append(f"SANs: {', '.join(sans)}")
    except ssl.SSLError as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] SSL Error: {e}"]
    except Exception as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] Cannot connect port 443: {e}"]
    return result


def mod_subdomains(target: str) -> dict:
    """Subdomain discovery via free APIs — crt.sh, AnubisDB, RapidDNS"""
    result = {"name": "SUBDOMAINS", "lines": [], "status": "ok"}
    found = set()

    # crt.sh
    try:
        r = requests.get(f"https://crt.sh/?q={target}&output=json",
                         headers=HEADERS, timeout=15)
        if r.status_code == 200:
            for entry in r.json():
                for name in entry.get("name_value", "").split("\n"):
                    name = name.strip().lstrip("*.")
                    if name.endswith(f".{target}") or name == target:
                        found.add(name)
    except Exception:
        pass

    # AnubisDB
    try:
        r = requests.get(f"https://jldc.me/anubis/subdomains/{target}",
                         headers=HEADERS, timeout=15)
        if r.status_code == 200:
            for sub in r.json():
                found.add(sub.strip())
    except Exception:
        pass

    # HackerTarget
    try:
        r = requests.get(f"https://api.hackertarget.com/hostsearch/?q={target}",
                         headers=HEADERS, timeout=15)
        if r.status_code == 200 and "error" not in r.text.lower():
            for line in r.text.strip().splitlines():
                if "," in line:
                    sub = line.split(",")[0].strip()
                    if sub:
                        found.add(sub)
    except Exception:
        pass

    for sub in sorted(found):
        result["lines"].append(sub)

    if not found:
        result["lines"].append("No subdomains found via passive APIs")
    else:
        result["lines"].append(f"Total: {len(found)} subdomains")

    return result


def mod_whois(target: str) -> dict:
    """WHOIS via IANA/rdap"""
    result = {"name": "WHOIS", "lines": [], "status": "ok"}
    try:
        r = requests.get(f"https://rdap.org/domain/{target}",
                         headers=HEADERS, timeout=10)
        if r.status_code == 200:
            data = r.json()
            result["lines"].append(f"Name: {data.get('handle', target)}")
            result["lines"].append(f"Status: {', '.join(data.get('status', []))}")
            for event in data.get("events", []):
                result["lines"].append(f"{event.get('eventAction','')}: {event.get('eventDate','')}")
            for entity in data.get("entities", [])[:3]:
                roles = entity.get("roles", [])
                vcard = entity.get("vcardArray", [])
                result["lines"].append(f"Entity roles: {', '.join(roles)}")
        else:
            result["lines"].append(f"RDAP returned {r.status_code}")
    except Exception as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] WHOIS error: {e}"]
    return result


def mod_robots(target: str) -> dict:
    """robots.txt + sitemap"""
    result = {"name": "ROBOTS", "lines": [], "status": "ok"}
    for scheme in ["https", "http"]:
        try:
            r = requests.get(f"{scheme}://{target}/robots.txt",
                             headers=HEADERS, timeout=REQUEST_TIMEOUT, verify=False)
            if r.status_code == 200:
                result["lines"].append(r.text[:2000])
                for line in r.text.splitlines():
                    if line.lower().startswith("sitemap:"):
                        sitemap_url = line.split(":", 1)[1].strip()
                        result["lines"].append(f"Sitemap: {sitemap_url}")
                return result
        except Exception:
            continue
    result["status"] = "fail"
    result["lines"] = ["No robots.txt found"]
    return result


def mod_crawl(target: str) -> dict:
    """Web crawl — links, JS files, emails, forms"""
    result = {"name": "CRAWL", "lines": [], "status": "ok"}
    if not BS4_OK:
        result["status"] = "skip"
        result["lines"] = ["[SKIP] beautifulsoup4 not installed"]
        return result

    for scheme in ["https", "http"]:
        try:
            url = f"{scheme}://{target}"
            r = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT,
                             verify=False, allow_redirects=True)
            soup = BeautifulSoup(r.content, "html.parser")

            js  = [t["src"] for t in soup.find_all("script", src=True)]
            css = [t["href"] for t in soup.find_all("link", rel="stylesheet", href=True)]
            links = set()
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.startswith("http"):
                    links.add(href)
                elif not href.startswith("#"):
                    links.add(urljoin(url, href))

            emails = re.findall(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", r.text)
            forms  = soup.find_all("form")

            for j in js[:10]:    result["lines"].append(f"JS: {j}")
            for c in css[:5]:    result["lines"].append(f"CSS: {c}")
            for l in list(links)[:20]: result["lines"].append(f"Link: {l}")
            for e in set(emails): result["lines"].append(f"Email: {e}")
            result["lines"].append(f"Forms found: {len(forms)}")
            result["lines"].append(f"Total links: {len(links)}")
            return result
        except Exception:
            continue

    result["status"] = "fail"
    result["lines"] = ["[!] Could not crawl"]
    return result


def mod_wayback(target: str) -> dict:
    """Wayback Machine — last 3 years of URLs"""
    result = {"name": "WAYBACK", "lines": [], "status": "ok"}
    try:
        from datetime import date
        curr = date.today().year
        r = requests.get(
            "http://web.archive.org/cdx/search/cdx",
            params={"url": f"{target}/*", "fl": "original",
                    "fastLatest": "true", "from": str(curr-3),
                    "to": str(curr), "limit": "50"},
            timeout=15
        )
        if r.status_code == 200:
            urls = list(set(r.text.strip().splitlines()))
            for u in urls[:50]:
                result["lines"].append(u)
            result["lines"].append(f"Total archived URLs: {len(urls)}")
        else:
            result["lines"].append(f"Wayback returned {r.status_code}")
    except Exception as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] Wayback error: {e}"]
    return result


def mod_vuln_scan(target: str) -> dict:
    """
    Lightweight vuln scan — parallel checks from omnisci3nt logic.
    Checks: security headers, XSS, open redirect, clickjacking,
    CORS, exposed .git, sensitive files, SQLi, LFI, sensitive robots,
    exposed API endpoints, directory listing.
    """
    result = {"name": "VULNSCAN", "lines": [], "status": "ok"}
    findings = []
    base_url = f"http://{target}" if not target.startswith("http") else target

    def _get(url, **kwargs):
        try:
            return requests.get(url, headers=HEADERS, timeout=5,
                                verify=False, allow_redirects=False, **kwargs)
        except Exception:
            return None

    def _post(url, **kwargs):
        try:
            return requests.post(url, headers=HEADERS, timeout=5,
                                 verify=False, **kwargs)
        except Exception:
            return None

    checks = {
        "Security Headers": lambda: _check_sec_headers(base_url, findings),
        "Clickjacking":     lambda: _check_xframe(base_url, findings),
        "CORS":             lambda: _check_cors(base_url, findings),
        "Exposed .git":     lambda: _check_git(base_url, findings),
        "Sensitive Files":  lambda: _check_sensitive(base_url, findings),
        "SQLi (basic)":     lambda: _check_sqli(base_url, findings),
        "LFI (basic)":      lambda: _check_lfi(base_url, findings),
        "XSS (basic)":      lambda: _check_xss(base_url, findings),
        "Open Redirect":    lambda: _check_redirect(base_url, findings),
        "Dir Listing":      lambda: _check_dirlisting(base_url, findings),
        "Exposed API":      lambda: _check_api(base_url, findings),
        "Robots Sensitive": lambda: _check_robots_sensitive(base_url, findings),
        "Cookie Security":  lambda: _check_cookies(base_url, findings),
        "Info Disclosure":  lambda: _check_info_disclosure(base_url, findings),
    }

    lock = threading.Lock()

    def run_check(name, fn):
        try:
            fn()
        except Exception as e:
            with lock:
                findings.append(f"[!] {name} check error: {e}")

    with ThreadPoolExecutor(max_workers=8) as ex:
        futures = {ex.submit(run_check, n, fn): n for n, fn in checks.items()}
        for f in as_completed(futures):
            pass  # results go into findings list directly

    result["lines"] = findings if findings else ["No obvious vulnerabilities detected"]
    return result


# ── Vuln check helpers ─────────────────────────────────────────────────────────
def _check_sec_headers(url, out):
    r = requests.get(url, headers=HEADERS, timeout=5, verify=False)
    required = ["Content-Security-Policy","Strict-Transport-Security",
                "X-Frame-Options","X-Content-Type-Options","Referrer-Policy"]
    missing = [h for h in required if h not in r.headers]
    if missing:
        out.append(f"[⚠] Missing security headers: {', '.join(missing)}")
    else:
        out.append("[✔] Security headers present")

def _check_xframe(url, out):
    r = requests.get(url, headers=HEADERS, timeout=5, verify=False)
    if "X-Frame-Options" not in r.headers:
        out.append(f"[⚠] Clickjacking: No X-Frame-Options at {url}")

def _check_cors(url, out):
    r = requests.options(url, headers={**HEADERS,"Origin":"https://evil.com"}, timeout=5, verify=False)
    acao = r.headers.get("Access-Control-Allow-Origin","")
    if acao == "*" or "evil.com" in acao:
        out.append(f"[❌] CORS misconfiguration at {url}: {acao}")

def _check_git(url, out):
    for path in ["/.git/HEAD","/.git/config"]:
        r = requests.get(url+path, headers=HEADERS, timeout=5, verify=False)
        if r and r.status_code == 200 and ("ref:" in r.text or "repositoryformatversion" in r.text):
            out.append(f"[❌] Exposed .git directory at {url+path}")
            return
    out.append("[✔] .git not exposed")

def _check_sensitive(url, out):
    for path in ["/.env","/.env.backup","/backup.zip","/db.sql","/config.php"]:
        r = requests.get(url+path, headers=HEADERS, timeout=5, verify=False)
        if r and r.status_code == 200 and len(r.content) > 50:
            out.append(f"[❌] Sensitive file found: {url+path}")

def _check_sqli(url, out):
    for payload in ["'","\"","' OR '1'='1"]:
        r = requests.get(f"{url}/?id={payload}", headers=HEADERS, timeout=5, verify=False)
        if r and any(e in r.text.lower() for e in ["sql syntax","mysql error","unclosed quotation","odbc"]):
            out.append(f"[❌] Possible SQLi at {url}/?id={payload}")
            return
    out.append("[✔] No obvious SQLi")

def _check_lfi(url, out):
    for payload in ["../../../../etc/passwd","..%2F..%2Fetc%2Fpasswd"]:
        r = requests.get(f"{url}/?file={payload}", headers=HEADERS, timeout=5, verify=False)
        if r and "root:x:" in r.text:
            out.append(f"[❌] LFI confirmed at {url}/?file={payload}")
            return
    out.append("[✔] No obvious LFI")

def _check_xss(url, out):
    r = requests.get(f"{url}/?q=<script>alert(1)</script>",
                     headers=HEADERS, timeout=5, verify=False)
    if r and "<script>alert(1)</script>" in r.text:
        out.append(f"[❌] Reflected XSS at {url}/?q=...")
    else:
        out.append("[✔] No reflected XSS")

def _check_redirect(url, out):
    for path in ["/redirect?url=https://google.com","/out?target=https://google.com"]:
        r = requests.get(url+path, headers=HEADERS, timeout=5,
                         verify=False, allow_redirects=False)
        if r and r.status_code in [301,302] and "google.com" in r.headers.get("Location",""):
            out.append(f"[⚠] Open redirect at {url+path}")

def _check_dirlisting(url, out):
    for d in ["/images/","/uploads/","/backup/","/files/"]:
        r = requests.get(url+d, headers=HEADERS, timeout=5, verify=False)
        if r and "Index of" in r.text and r.status_code == 200:
            out.append(f"[⚠] Directory listing at {url+d}")

def _check_api(url, out):
    for path in ["/api/","/graphql","/v1/","/api/v1/"]:
        r = requests.get(url+path, headers=HEADERS, timeout=5, verify=False)
        if r and r.status_code == 200 and "application/json" in r.headers.get("Content-Type",""):
            out.append(f"[⚠] Exposed API endpoint: {url+path}")

def _check_robots_sensitive(url, out):
    r = requests.get(url+"/robots.txt", headers=HEADERS, timeout=5, verify=False)
    if r and r.status_code == 200:
        for line in r.text.splitlines():
            if any(x in line.lower() for x in ["admin","backup","db","secret","private","config"]):
                out.append(f"[⚠] Sensitive robots.txt entry: {line.strip()}")

def _check_cookies(url, out):
    r = requests.get(url, headers=HEADERS, timeout=5, verify=False)
    cookies = r.headers.get("Set-Cookie","") if r else ""
    if cookies:
        missing = []
        if "Secure" not in cookies:   missing.append("Secure")
        if "HttpOnly" not in cookies: missing.append("HttpOnly")
        if "SameSite" not in cookies: missing.append("SameSite")
        if missing:
            out.append(f"[⚠] Cookie missing flags: {', '.join(missing)}")

def _check_info_disclosure(url, out):
    r = requests.get(url, headers=HEADERS, timeout=5, verify=False)
    if not r: return
    server = r.headers.get("Server","")
    powered = r.headers.get("X-Powered-By","")
    if server: out.append(f"[⚠] Server header exposed: {server}")
    if powered: out.append(f"[⚠] X-Powered-By exposed: {powered}")


def mod_dirscan(target: str) -> dict:
    """
    Async directory brute-force — uses built-in wordlist (no file needed).
    Logic from omnisci3nt dirtest.py
    """
    result = {"name": "DIRSCAN", "lines": [], "status": "ok"}
    if not AIOHTTP_OK:
        result["status"] = "skip"
        result["lines"] = ["[SKIP] aiohttp not installed"]
        return result

    WORDLIST = [
        "admin","login","wp-admin","dashboard","api","v1","v2","config","backup",
        "uploads","images","static","assets","js","css","includes","lib","src",
        "test","dev","staging","old","new","beta","temp","tmp","log","logs",
        "files","docs","doc","about","contact","register","signup","signin",
        "logout","profile","user","users","account","accounts","settings",
        "panel","manager","management","portal","console","shell","phpinfo.php",
        ".env","robots.txt","sitemap.xml","wp-login.php","phpmyadmin",
        "webmail","mail","email","smtp","ftp","ssh","database","db","sql",
        "readme.txt","README.md","changelog","CHANGELOG","license","LICENSE",
    ]

    found = []
    base_url = f"http://{target}" if not target.startswith("http") else target

    async def _scan():
        conn = aiohttp.TCPConnector(limit=50, ssl=False)
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=5, sock_read=5)
        async with aiohttp.ClientSession(connector=conn, timeout=timeout,
                                          headers=HEADERS) as session:
            async def _fetch(path):
                url = f"{base_url}/{path}"
                try:
                    async with session.get(url, allow_redirects=False) as resp:
                        if resp.status in [200, 301, 302, 403]:
                            found.append(f"{resp.status} {url}")
                except Exception:
                    pass

            tasks = [_fetch(w) for w in WORDLIST]
            await asyncio.gather(*tasks, return_exceptions=True)

    try:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(_scan())
        loop.close()
    except Exception as e:
        result["status"] = "fail"
        result["lines"] = [f"[!] Dirscan error: {e}"]
        return result

    result["lines"] = found if found else ["No directories found"]
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  PARALLEL ORCHESTRATOR — runs all modules simultaneously
# ══════════════════════════════════════════════════════════════════════════════

# Heavy modules run in own thread pool — lighter ones run concurrently too
_HEAVY = {"PORTSCAN", "SUBDOMAINS", "WAYBACK", "DIRSCAN", "VULNSCAN"}
_LIGHT = {"DNS", "HEADERS", "SSL", "WHOIS", "ROBOTS", "CRAWL"}

ALL_MODULES = {
    "DNS":        mod_dns,
    "PORTSCAN":   mod_ports,
    "HEADERS":    mod_headers,
    "SSL":        mod_ssl,
    "SUBDOMAINS": mod_subdomains,
    "WHOIS":      mod_whois,
    "ROBOTS":     mod_robots,
    "CRAWL":      mod_crawl,
    "WAYBACK":    mod_wayback,
    "VULNSCAN":   mod_vuln_scan,
    "DIRSCAN":    mod_dirscan,
}


def run_recon_parallel(target: str, recon_dir: str) -> dict[str, str]:
    """
    Run ALL recon modules in parallel threads.
    Heavy modules (port scan, subdomain, dirscan, vulnscan, wayback)
    run concurrently with light modules.
    Returns dict {module_name: output_text}
    """
    ensure_dir(recon_dir)
    tw = _tw()
    results = {}
    lock = threading.Lock()

    # Progress display
    status = {name: "⏳" for name in ALL_MODULES}
    start_times = {name: time.time() for name in ALL_MODULES}

    def _print_status():
        lines = []
        for name in ALL_MODULES:
            st = status[name]
            elapsed = time.time() - start_times[name]
            mm, ss = divmod(int(elapsed), 60)
            timer = f"{mm:02d}:{ss:02d}"
            if st == "⏳":
                col = YEL
            elif st == "✔":
                col = GRN
            else:
                col = RED
            lines.append(f"  {col}{name:<14}{R}  {st}  {DIM}{timer}{R}")
        sys.stdout.write("\033[2J\033[H")  # clear screen
        print(f"\n{CYN}{'═'*tw}{R}")
        print(f"  {YEL}PARALLEL RECON IN PROGRESS{R}")
        print(f"{CYN}{'─'*tw}{R}\n")
        for l in lines:
            print(l)
        print(f"\n{CYN}{'─'*tw}{R}")
        sys.stdout.flush()

    def _run_module(name, fn):
        start_times[name] = time.time()
        try:
            r = fn(target)
            with lock:
                status[name] = "✔"
                output = "\n".join(r.get("lines", []))
                results[name] = output
                save_file(os.path.join(recon_dir, f"{name.lower()}.txt"), output)
        except Exception as e:
            with lock:
                status[name] = "✘"
                results[name] = f"[ERROR] {e}"

    # Start all modules as threads
    threads = []
    for name, fn in ALL_MODULES.items():
        t = threading.Thread(target=_run_module, args=(name, fn), daemon=True)
        t.start()
        threads.append((name, t))

    # Live status updater
    while any(t.is_alive() for _, t in threads):
        _print_status()
        time.sleep(1)

    # Final join
    for _, t in threads:
        t.join(timeout=0)

    _print_status()
    return results


def print_recon_summary(results: dict[str, str]):
    tw = _tw()
    print(f"\n{CYN}{'═'*tw}{R}")
    print(f"  {YEL}RECON SUMMARY{R}")
    print(f"{CYN}{'─'*tw}{R}")
    for name, output in results.items():
        lines = [l for l in output.strip().splitlines() if l.strip()]
        lcount = len(lines)
        max_prev = max(tw - 42, 20)
        if output.startswith("[ERROR]") or output.startswith("[TIMEOUT]"):
            status = f"{RED}✘{R}"
            preview = f"{RED}{output[:max_prev]}{R}"
        elif output.startswith("[SKIP]"):
            status = f"{YEL}~{R}"
            preview = f"{YEL}{output[:max_prev]}{R}"
        else:
            status = f"{GRN}✔{R}"
            preview = f"{DIM}{lines[0][:max_prev] if lines else '(empty)'}{R}"
        print(f"  {status}  {BLD}{name:<14}{R}  {WHT}{lcount:>4} lines{R}  │  {preview}")
    print(f"{CYN}{'═'*tw}{R}\n")
