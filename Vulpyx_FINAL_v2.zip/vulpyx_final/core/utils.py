"""
VULPYX – Utility functions
"""
import os
import sys
import subprocess


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def save_file(path: str, data: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)


def load_file(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""
    except Exception as e:
        return f"[ERROR reading {path}: {e}]"


def load_prompt(path: str) -> str:
    content = load_file(path)
    if not content:
        raise FileNotFoundError(f"Prompt file missing or empty: {path}")
    return content


def cmd_available(cmd: str) -> bool:
    return subprocess.run(
        ["which", cmd],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    ).returncode == 0


def _reopen_stdin():
    """Reopen stdin from /dev/tty if broken by a subprocess."""
    try:
        sys.stdin = open("/dev/tty", "r")
    except Exception:
        pass


def multiline_input(prompt: str) -> str:
    """
    Collect multi-line input until user types END alone on a line.
    Recovers from EOFError caused by subprocesses consuming stdin.
    """
    if sys.stdin.closed:
        _reopen_stdin()
    print(prompt)
    lines = []
    while True:
        try:
            line = input()
        except EOFError:
            _reopen_stdin()
            try:
                line = input()
            except Exception:
                break
        if line.strip().upper() == "END":
            break
        lines.append(line)
    return "\n".join(lines)
