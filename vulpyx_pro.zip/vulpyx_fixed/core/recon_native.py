"""
VULPYX – Native Parallel Recon Engine
Runs all 11 recon modules concurrently using thread pool.
Fixed: proper sync DNS, real SSL via stdlib, URL normalisation,
       deduplicated ports, per-task timeouts, no hanging.
"""

import ssl
import socket
import json
import os
import re
import time
import requests
import concurrent.futures
from datetime import datetime
from typing import Dict
from urllib.parse import urljoin, urlparse

try:
    import dns.resolver
    import dns.exception
    DNS_OK = True
except ImportError:
    DNS_OK = False

try:
    from bs4 import BeautifulSoup
    BS4_OK = True
except ImportError:
    BS4_OK = False

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── Constants ──────────────────────────────────────────────────────────────────
_CONNECT_TIMEOUT = 4
_HTTP_TIMEOUT    = 10
_DNS_TIMEOUT     = 5
_UA = "Mozilla/5.0 (X11; Linux x86_64; rv:120.0) Gecko/20100101 Firefox/120.0"

TOP_PORTS = sorted(set([
    21, 22, 23, 25, 53, 80, 110, 135, 139, 143,
    443, 445, 993, 995, 1433, 1521, 3306, 3389,
    5432, 5900, 6379, 8080, 8443, 8000, 8888,
    9200, 9300, 27017
]))

_SERVICE_MAP = {
    21:"ftp",22:"ssh",23:"telnet",25:"smtp",53:"dns",
    80:"http",110:"pop3",135:"msrpc",139:"netbios-ssn",
    143:"imap",443:"https",445:"smb",993:"imaps",
    995:"pop3s",1433:"mssql",1521:"oracle",3306:"mysql",
    3389:"rdp",5432:"postgresql",5900:"vnc",6379:"redis",
    8080:"http-alt",8443:"https-alt",8000:"http-alt",
    8888:"http-alt",9200:"elasticsearch",9300:"elasticsearch",
    27017:"mongodb",
}


def _normalise(target: str):
    target = target.strip().rstrip("/")
    if target.startswith(("http://","https://")):
        parsed   = urlparse(target)
        hostname = parsed.hostname or target
        base_url = target
    else:
        hostname = target
        base_url = f"http://{target}"
    return hostname, base_url


# ══════════════════════════════════════════════════════════════════════════════
#  Module functions (all synchronous, run in ThreadPoolExecutor)
# ══════════════════════════════════════════════════════════════════════════════

def _dns_scan(hostname):
    if not DNS_OK:
        return f"DNS: dnspython not installed — skipped"
    lines = [f"DNS Enumeration: {hostname}", ""]
    r = dns.resolver.Resolver()
    r.lifetime = _DNS_TIMEOUT
    r.timeout  = _DNS_TIMEOUT
    for rtype in ["A","AAAA","MX","NS","TXT","CNAME"]:
        try:
            for rdata in r.resolve(hostname, rtype):
                lines.append(f"  {rtype:<6} {rdata}")
        except Exception:
            pass
    # SPF
    try:
        for rdata in r.resolve(hostname, "TXT"):
            if "v=spf1" in str(rdata):
                lines.append(f"  SPF    {str(rdata)[:80]}")
    except Exception:
        pass
    # DMARC
    try:
        for rdata in r.resolve(f"_dmarc.{hostname}", "TXT"):
            lines.append(f"  DMARC  {str(rdata)[:80]}")
    except Exception:
        pass
    return "\n".join(lines)


def _port_scan(hostname):
    open_ports = []
    def _check(port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(_CONNECT_TIMEOUT)
                if s.connect_ex((hostname, port)) == 0:
                    return port
        except Exception:
            pass
        return None
    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
        for result in ex.map(_check, TOP_PORTS):
            if result:
                open_ports.append(result)
    open_ports.sort()
    lines = [f"Port Scan: {hostname}", ""]
    if open_ports:
        for p in open_ports:
            lines.append(f"  {p}/tcp  open  {_SERVICE_MAP.get(p,'unknown')}")
    else:
        lines.append("  No open ports found")
    return "\n".join(lines)


def _headers_scan(base_url):
    lines = [f"HTTP Headers: {base_url}", ""]
    try:
        r = requests.get(base_url, timeout=_HTTP_TIMEOUT,
                         headers={"User-Agent":_UA},
                         allow_redirects=True, verify=False)
        lines.append(f"  Status   : {r.status_code}")
        lines.append(f"  Final URL: {r.url}")
        sec = ["Content-Security-Policy","Strict-Transport-Security",
               "X-Frame-Options","X-Content-Type-Options",
               "Referrer-Policy","X-XSS-Protection"]
        lines.append("  Security Headers:")
        for h in sec:
            v = r.headers.get(h)
            lines.append(f"    {'✔' if v else '✘'} {h}" + (f": {v[:80]}" if v else ""))
        lines.append("  All Response Headers:")
        for k,v in r.headers.items():
            lines.append(f"    {k}: {v[:120]}")
    except Exception as e:
        lines.append(f"  ERROR: {e}")
    return "\n".join(lines)


def _ssl_inspect(hostname):
    lines = [f"SSL/TLS: {hostname}", ""]
    for verify in (True, False):
        try:
            ctx = ssl.create_default_context()
            if not verify:
                ctx.check_hostname = False
                ctx.verify_mode    = ssl.CERT_NONE
            with socket.create_connection((hostname, 443), timeout=_CONNECT_TIMEOUT) as sock:
                with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert   = ssock.getpeercert()
                    proto  = ssock.version()
                    cipher = ssock.cipher()
            # Got cert — parse it
            subject = dict(x[0] for x in cert.get("subject",[]))
            issuer  = dict(x[0] for x in cert.get("issuer", []))
            lines.append(f"  Common Name : {subject.get('commonName','N/A')}")
            lines.append(f"  Issuer      : {issuer.get('organizationName','N/A')}")
            lines.append(f"  Protocol    : {proto}")
            lines.append(f"  Cipher      : {cipher[0] if cipher else 'N/A'}")
            not_after = cert.get("notAfter","")
            if not_after:
                expiry = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                days   = (expiry - datetime.utcnow()).days
                flag   = "✔" if days>30 else ("⚠ EXPIRING SOON" if days>0 else "✘ EXPIRED")
                lines.append(f"  Expires     : {not_after}  ({days}d)  {flag}")
            sans = cert.get("subjectAltName",[])
            if sans:
                lines.append(f"  SANs ({len(sans)}): " + ", ".join(v for _,v in sans[:8]))
            if proto in ("SSLv2","SSLv3","TLSv1","TLSv1.1"):
                lines.append(f"  ⚠ WEAK PROTOCOL: {proto}")
            if not verify:
                lines.append("  ⚠ Certificate validation FAILED (self-signed or expired)")
            return "\n".join(lines)
        except (ConnectionRefusedError, OSError):
            lines.append("  Port 443 not open")
            return "\n".join(lines)
        except ssl.SSLError:
            if verify:
                continue   # retry without verification
            lines.append("  SSL handshake failed")
            return "\n".join(lines)
        except Exception as e:
            lines.append(f"  ERROR: {e}")
            return "\n".join(lines)
    return "\n".join(lines)


def _subdomain_discovery(hostname):
    lines = [f"Subdomain Discovery: {hostname}", ""]
    found = set()
    # crt.sh
    try:
        r = requests.get(f"https://crt.sh/?q=%.{hostname}&output=json",
                         timeout=15, headers={"User-Agent":_UA})
        if r.status_code == 200:
            for entry in r.json():
                for sub in entry.get("name_value","").splitlines():
                    sub = sub.strip().lstrip("*.")
                    if sub.endswith(hostname) and sub != hostname:
                        found.add(sub)
    except Exception as e:
        lines.append(f"  crt.sh: {e}")

    # DNS brute
    wordlist = ["www","mail","smtp","ftp","admin","portal","vpn","api","dev",
                "staging","test","beta","blog","app","shop","cdn","static",
                "assets","m","mobile","support","help","status"]
    if DNS_OK:
        r2 = dns.resolver.Resolver()
        r2.lifetime = 3
        r2.timeout  = 3
        def _resolve(sub):
            try:
                r2.resolve(f"{sub}.{hostname}", "A")
                return f"{sub}.{hostname}"
            except Exception:
                return None
        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
            for result in ex.map(_resolve, wordlist):
                if result:
                    found.add(result)

    if found:
        lines.append(f"  Found {len(found)} subdomains:")
        for s in sorted(found):
            lines.append(f"    {s}")
    else:
        lines.append("  No subdomains found")
    return "\n".join(lines)


def _whois_lookup(hostname):
    lines = [f"WHOIS/RDAP: {hostname}", ""]
    try:
        r = requests.get(f"https://rdap.org/domain/{hostname}",
                         timeout=_HTTP_TIMEOUT,
                         headers={"User-Agent":_UA,"Accept":"application/json"})
        if r.status_code == 200:
            data = r.json()
            lines.append(f"  LDH Name    : {data.get('ldhName','N/A')}")
            for entity in data.get("entities",[]):
                if "registrar" in entity.get("roles",[]):
                    vcards = entity.get("vcardArray",[[],[]])[1]
                    for card in vcards:
                        if card[0] == "fn":
                            lines.append(f"  Registrar   : {card[3]}")
            for ev in data.get("events",[]):
                action = ev.get("eventAction","")
                date   = ev.get("eventDate","")[:10]
                if action in ("registration","expiration","last changed"):
                    lines.append(f"  {action.title():<14}: {date}")
            ns_list = [ns.get("ldhName","") for ns in data.get("nameservers",[])]
            if ns_list:
                lines.append(f"  Nameservers : {', '.join(ns_list[:4])}")
        else:
            lines.append(f"  HTTP {r.status_code}")
    except Exception as e:
        lines.append(f"  ERROR: {e}")
    return "\n".join(lines)


def _robots_txt(base_url):
    lines = [f"Robots/Sitemap: {base_url}", ""]
    sess = requests.Session()
    sess.headers["User-Agent"] = _UA
    for path in ["/robots.txt","/sitemap.xml","/sitemap_index.xml"]:
        try:
            r = sess.get(base_url+path, timeout=_HTTP_TIMEOUT,
                         allow_redirects=True, verify=False)
            lines.append(f"  [{path}]  HTTP {r.status_code}")
            if r.status_code == 200:
                lines.append(r.text[:600])
        except Exception as e:
            lines.append(f"  [{path}]  ERROR: {e}")
    return "\n".join(lines)


def _web_crawl(base_url):
    lines   = [f"Web Crawl: {base_url}", ""]
    visited, queue = set(), [base_url]
    all_links, emails, forms, js_files = [], set(), [], []
    sess = requests.Session()
    sess.headers["User-Agent"] = _UA
    parsed_base = urlparse(base_url)
    MAX_PAGES = 8
    while queue and len(visited) < MAX_PAGES:
        url = queue.pop(0)
        if url in visited:
            continue
        visited.add(url)
        try:
            r = sess.get(url, timeout=_HTTP_TIMEOUT,
                         allow_redirects=True, verify=False)
            if "text/html" not in r.headers.get("Content-Type",""):
                continue
            if not BS4_OK:
                continue
            soup = BeautifulSoup(r.text,"html.parser")
            if len(visited)==1 and soup.title:
                lines.append(f"  Title: {soup.title.string}")
            for a in soup.find_all("a",href=True):
                full = urljoin(url, a["href"].strip())
                p    = urlparse(full)
                if p.scheme in ("http","https"):
                    all_links.append(full)
                    if p.netloc==parsed_base.netloc and full not in visited:
                        queue.append(full)
            for m in re.findall(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",r.text):
                emails.add(m)
            for form in soup.find_all("form"):
                forms.append(f"{form.get('method','GET').upper()} {urljoin(url,form.get('action',''))}")
            for script in soup.find_all("script",src=True):
                js_files.append(urljoin(url,script["src"]))
        except Exception:
            continue
    lines.append(f"  Pages: {len(visited)}  Links: {len(all_links)}")
    if emails:
        lines.append(f"  Emails: {', '.join(list(emails)[:8])}")
    if forms:
        lines.append(f"  Forms ({len(forms)}):")
        for f in forms[:5]: lines.append(f"    {f}")
    if js_files:
        lines.append(f"  JS files ({len(js_files)}):")
        for j in js_files[:5]: lines.append(f"    {j}")
    if all_links:
        lines.append("  Sample links:")
        for lnk in list(dict.fromkeys(all_links))[:10]:
            lines.append(f"    {lnk}")
    return "\n".join(lines)


def _wayback_machine(hostname):
    lines = [f"Wayback Machine: {hostname}", ""]
    try:
        r = requests.get(
            "http://web.archive.org/cdx/search/cdx",
            params={"url":f"{hostname}/*","output":"json","limit":"20",
                    "fl":"original,statuscode,timestamp",
                    "collapse":"urlkey","from":"20220101"},
            timeout=15, headers={"User-Agent":_UA})
        if r.status_code == 200:
            rows = r.json()
            if len(rows) > 1:
                lines.append(f"  {len(rows)-1} archived URLs:")
                for row in rows[1:11]:
                    lines.append(f"    [{row[2][:8]}] {row[1]}  {row[0]}")
            else:
                lines.append("  No archived URLs found")
        else:
            lines.append(f"  HTTP {r.status_code}")
    except Exception as e:
        lines.append(f"  ERROR: {e}")
    return "\n".join(lines)


def _vuln_scan(base_url):
    lines    = [f"Vulnerability Scan: {base_url}", ""]
    findings = []
    sess     = requests.Session()
    sess.headers["User-Agent"] = _UA

    def _get(path, **kw):
        try:
            return sess.get(base_url.rstrip("/")+path, timeout=_HTTP_TIMEOUT,
                            allow_redirects=False, verify=False, **kw)
        except Exception:
            return None

    # Security headers
    r = _get("/")
    if r:
        hdrs = {k.lower() for k in r.headers}
        if "x-frame-options" not in hdrs:
            findings.append("MEDIUM: Missing X-Frame-Options — clickjacking risk")
        if "content-security-policy" not in hdrs:
            findings.append("MEDIUM: Missing Content-Security-Policy")
        if "strict-transport-security" not in hdrs:
            findings.append("LOW: Missing HSTS")

    # .git
    r = _get("/.git/HEAD")
    if r and r.status_code == 200 and b"ref:" in r.content:
        findings.append("CRITICAL: /.git/HEAD exposed — source code accessible")

    # .env
    r = _get("/.env")
    if r and r.status_code == 200 and len(r.content) > 5:
        findings.append("CRITICAL: /.env exposed — credentials may be leaked")

    # Backup files
    for bk in ["/backup.zip","/backup.tar.gz","/db.sql","/database.sql","/dump.sql"]:
        r = _get(bk)
        if r and r.status_code == 200:
            findings.append(f"CRITICAL: Backup file exposed: {bk}")

    # phpinfo
    r = _get("/phpinfo.php")
    if r and r.status_code == 200 and b"phpinfo" in r.content:
        findings.append("HIGH: phpinfo.php exposed")

    # Admin panels
    for panel in ["/admin","/admin/login","/wp-admin","/phpmyadmin","/manager/html","/dashboard"]:
        r = _get(panel)
        if r and r.status_code in (200,401,403):
            findings.append(f"INFO: Admin panel: {panel} (HTTP {r.status_code})")

    # CORS
    try:
        r = sess.get(base_url, timeout=_HTTP_TIMEOUT, verify=False,
                     headers={"Origin":"https://evil.com"})
        acao = r.headers.get("Access-Control-Allow-Origin","")
        if acao in ("*","https://evil.com"):
            findings.append(f"HIGH: CORS misconfiguration — ACAO: {acao}")
    except Exception:
        pass

    # XSS reflection
    xss = "<script>alert(1)</script>"
    try:
        r = sess.get(base_url+f"/?q={xss}", timeout=_HTTP_TIMEOUT, verify=False)
        if r and xss in r.text:
            findings.append("HIGH: Reflected XSS — payload echoed in response")
    except Exception:
        pass

    # SQLi errors
    for pl in ["'","1' OR '1'='1"]:
        try:
            r = sess.get(base_url+f"/?id={pl}", timeout=_HTTP_TIMEOUT, verify=False)
            if r:
                body = r.text.lower()
                if any(e in body for e in ["sql syntax","mysql_fetch","ora-00",
                                            "syntax error","unclosed quotation"]):
                    findings.append(f"CRITICAL: SQL error triggered — possible SQLi (payload: {pl})")
                    break
        except Exception:
            pass

    # Cookie flags
    try:
        r = sess.get(base_url, timeout=_HTTP_TIMEOUT, verify=False)
        for ck in r.cookies:
            issues = []
            if not ck.secure:    issues.append("no Secure")
            if not ck.has_nonstandard_attr("HttpOnly"): issues.append("no HttpOnly")
            if issues:
                findings.append(f"MEDIUM: Cookie '{ck.name}' — {', '.join(issues)}")
    except Exception:
        pass

    if findings:
        lines.append(f"  {len(findings)} finding(s):")
        for f in findings:
            lines.append(f"    {f}")
    else:
        lines.append("  No obvious vulnerabilities detected")
    return "\n".join(lines)


def _dir_scan(base_url):
    wordlist = [
        "admin","administrator","login","wp-admin","wp-login.php",
        "phpmyadmin","dashboard","panel","cpanel","webmail",
        "mail","api","api/v1","api/v2","v1","v2",
        "backup","backups","db","database","sql","dump",
        "config","configuration","conf","settings",
        ".git",".env",".htaccess",".htpasswd",
        "uploads","upload","files","static","assets","media",
        "tmp","temp","cache","log","logs",
        "test","dev","development","staging","old","bak",
        "phpinfo.php","info.php","test.php",
        "robots.txt","sitemap.xml","crossdomain.xml","security.txt",
    ]
    lines = [f"Directory Scan: {base_url}", ""]
    found = []
    sess  = requests.Session()
    sess.headers["User-Agent"] = _UA

    def _probe(path):
        try:
            r = sess.get(base_url.rstrip("/")+"/"+path,
                         timeout=_HTTP_TIMEOUT, allow_redirects=False, verify=False)
            if r.status_code in (200,204,301,302,401,403):
                return (path, r.status_code)
        except Exception:
            pass
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
        for res in ex.map(_probe, wordlist):
            if res:
                found.append(res)

    if found:
        lines.append(f"  {len(found)} paths found:")
        for path, code in found:
            flag = " ← INTERESTING" if code in (200,401) else ""
            lines.append(f"    HTTP {code}  /{path}{flag}")
    else:
        lines.append("  No paths found")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  Public runner
# ══════════════════════════════════════════════════════════════════════════════

def run_recon_parallel(target: str, recon_dir: str) -> Dict[str, str]:
    """
    Run all 11 modules concurrently in a thread pool.
    Each module has its own internal timeout — guaranteed no hang.
    """
    hostname, base_url = _normalise(target)
    os.makedirs(recon_dir, exist_ok=True)

    tasks = [
        ("DNS",        _dns_scan,            hostname),
        ("PORTSCAN",   _port_scan,           hostname),
        ("HEADERS",    _headers_scan,        base_url),
        ("SSL",        _ssl_inspect,         hostname),
        ("SUBDOMAINS", _subdomain_discovery, hostname),
        ("WHOIS",      _whois_lookup,        hostname),
        ("ROBOTS",     _robots_txt,          base_url),
        ("CRAWL",      _web_crawl,           base_url),
        ("WAYBACK",    _wayback_machine,     hostname),
        ("VULNSCAN",   _vuln_scan,           base_url),
        ("DIRSCAN",    _dir_scan,            base_url),
    ]

    results = {}

    def _run(key, fn, arg):
        try:
            output = fn(arg)
        except Exception as e:
            output = f"[{key}] EXCEPTION: {e}"
        try:
            with open(os.path.join(recon_dir, f"{key}.txt"), "w", encoding="utf-8") as f:
                f.write(output)
        except Exception:
            pass
        return key, output

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(tasks)) as ex:
        future_map = {ex.submit(_run, key, fn, arg): key for key, fn, arg in tasks}
        for fut in concurrent.futures.as_completed(future_map, timeout=120):
            try:
                key, output = fut.result(timeout=5)
                results[key] = output
            except Exception as e:
                key = future_map[fut]
                results[key] = f"[{key}] TIMEOUT/ERROR: {e}"

    return results


def print_recon_summary(results: Dict[str, str]):
    try:
        from core.banner import GRN, YEL, RED, CYN, WHT, DIM, R, BLD, _tw
    except ImportError:
        GRN = YEL = RED = CYN = WHT = DIM = R = BLD = ""
        def _tw(): return 80

    tw = _tw()
    print(f"\n{CYN}{'═'*tw}{R}")
    print(f"  {YEL}RECON SUMMARY{R}\n")

    order = ["DNS","PORTSCAN","HEADERS","SSL","SUBDOMAINS",
             "WHOIS","ROBOTS","CRAWL","WAYBACK","VULNSCAN","DIRSCAN"]
    for mod in order:
        output = results.get(mod,"[not run]")
        ok     = "ERROR" not in output and "TIMEOUT" not in output and "EXCEPTION" not in output
        status = f"{GRN}OK{R}" if ok else f"{RED}FAIL{R}"
        lines  = len(output.splitlines())
        print(f"  {CYN}{mod:<12}{R}  {status}  {DIM}({lines} lines){R}")

    print(f"\n{CYN}{'═'*tw}{R}\n")

    for mod in order:
        output = results.get(mod,"")
        if not output:
            continue
        print(f"\n{CYN}── {mod} {'─'*(max(0,_tw()-len(mod)-4))}{R}")
        for line in output.splitlines()[:40]:
            print(f"  {line}")
        total = len(output.splitlines())
        if total > 40:
            print(f"  {DIM}... ({total-40} more lines — see recon/{mod}.txt){R}")
