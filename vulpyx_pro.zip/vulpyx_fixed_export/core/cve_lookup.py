"""
VULPYX – CVE Lookup Engine
Queries NIST NVD API (free, no API key needed) for real CVEs
based on services discovered during recon.
Fixed: port-scan output parser now handles both nmap AND native PORTSCAN format.
"""
import re
import time
import requests

from core.banner import (
    print_info, print_ok, print_warn, print_err,
    GRN, YEL, RED, CYN, MGN, WHT, DIM, R, BLD, _tw
)

NVD_API   = "https://services.nvd.nist.gov/rest/json/cves/2.0"
TIMEOUT   = 12
MAX_CVES  = 5

SEV_COLOR = {
    "CRITICAL": RED,
    "HIGH":     "\033[1;31m",
    "MEDIUM":   YEL,
    "LOW":      GRN,
    "NONE":     DIM,
}

def _sev_color(sev: str) -> str:
    return SEV_COLOR.get(sev.upper(), WHT)


def extract_services(port_output: str) -> list:
    """
    Parse port scan output in two formats:
      1. nmap -sV style:   80/tcp   open   http   Apache httpd 2.4.49
      2. Native PORTSCAN:  80/tcp  open  http
    Returns list of { port, protocol, service, version }
    """
    services = []
    # Handles both nmap verbose and our native format
    pattern = re.compile(
        r"(\d+)/(tcp|udp)\s+open\s+([\w\-\.]+)\s*(.*)"
    )
    for line in port_output.splitlines():
        m = pattern.match(line.strip())
        if m:
            port, proto, svc, version = m.groups()
            services.append({
                "port":     port,
                "protocol": proto,
                "service":  svc.strip(),
                "version":  version.strip(),
            })
    return services


def _query_nvd(keyword: str) -> list:
    try:
        resp = requests.get(
            NVD_API,
            params={"keywordSearch": keyword, "resultsPerPage": MAX_CVES},
            timeout=TIMEOUT,
            headers={"User-Agent": "Vulpyx/3.0"},
        )
        if resp.status_code == 429:
            print_warn("NVD rate limit hit — waiting 10s...")
            time.sleep(10)
            resp = requests.get(
                NVD_API,
                params={"keywordSearch": keyword, "resultsPerPage": MAX_CVES},
                timeout=TIMEOUT,
                headers={"User-Agent": "Vulpyx/3.0"},
            )
        if resp.status_code != 200:
            return []

        results = []
        for item in resp.json().get("vulnerabilities", []):
            cve    = item.get("cve", {})
            cve_id = cve.get("id", "N/A")

            descs = cve.get("descriptions", [])
            desc  = next((d["value"] for d in descs if d["lang"] == "en"), "No description")
            desc  = desc[:120] + "..." if len(desc) > 120 else desc

            score    = "N/A"
            severity = "NONE"
            metrics  = cve.get("metrics", {})
            for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                if key in metrics and metrics[key]:
                    m = metrics[key][0].get("cvssData", {})
                    score    = str(m.get("baseScore", "N/A"))
                    severity = m.get("baseSeverity", "NONE")
                    break

            results.append({
                "id":       cve_id,
                "score":    score,
                "severity": severity.upper(),
                "desc":     desc,
            })
        return results
    except Exception:
        return []


def run_cve_lookup(port_output: str) -> dict:
    services = extract_services(port_output)
    if not services:
        print_warn("No services parsed from port scan output — skipping CVE lookup.")
        return {}

    results = {}
    for svc in services:
        # Use version string if available, otherwise service name
        keyword = svc["version"] if svc["version"] else svc["service"]
        if not keyword or keyword.lower() in ("tcpwrapped", "unknown", ""):
            continue

        label = f"{svc['port']}/{svc['service']}"
        print_info(f"CVE lookup → {WHT}{label}{R}  ({keyword[:40]})")

        cves = _query_nvd(keyword)
        if cves:
            results[label] = cves
            print_ok(f"  {len(cves)} CVE(s) found")
        else:
            print_warn(f"  No CVEs found")

        time.sleep(0.7)   # NVD rate limit: ~10 req/min without API key

    return results


def print_cve_table(cve_results: dict):
    if not cve_results:
        print_warn("No CVEs to display.\n")
        return

    tw = _tw()
    print(f"\n{CYN}{'═'*tw}{R}")
    print(f"  {YEL}CVE LOOKUP RESULTS{R}")
    print(f"{CYN}{'─'*tw}{R}\n")

    for service, cves in cve_results.items():
        print(f"  {MGN}▸  {BLD}{service}{R}")
        for cve in cves:
            score_f = 0.0
            try:
                score_f = float(cve["score"])
            except (ValueError, TypeError):
                pass
            col = _sev_color(cve["severity"])
            bar = _cvss_bar(score_f)
            print(f"     {CYN}{cve['id']:<20}{R}  "
                  f"{col}{cve['severity']:<8}{R}  "
                  f"CVSS {WHT}{cve['score']:<4}{R}  {bar}")
            print(f"     {DIM}{cve['desc']}{R}")
        print()
    print(f"{CYN}{'═'*tw}{R}\n")


def _cvss_bar(score: float, width: int = 10) -> str:
    filled = int((score / 10.0) * width)
    empty  = width - filled
    col    = RED if score >= 9.0 else "\033[1;31m" if score >= 7.0 else YEL if score >= 4.0 else GRN
    return f"{col}{'█'*filled}{DIM}{'░'*empty}{R}"


def cve_summary_for_llm(cve_results: dict) -> str:
    if not cve_results:
        return "No CVEs found for discovered services."
    lines = ["KNOWN CVEs FOR DISCOVERED SERVICES:\n"]
    for service, cves in cve_results.items():
        lines.append(f"Service: {service}")
        for c in cves:
            lines.append(f"  - {c['id']} | CVSS {c['score']} | {c['severity']} | {c['desc']}")
        lines.append("")
    return "\n".join(lines)
