# ============================================================
#  VULPYX – Configuration
# ============================================================

OLLAMA_URL   = "http://localhost:11434/api/generate"
MODEL        = "qwen2.5-coder:1.5b"   # default; overridden at runtime
MAX_METHODS  = 10

# ── Runtime model (set after model picker) ────────────────────────────────────
_runtime = {"model": MODEL}

def set_model(name: str):  _runtime["model"] = name
def get_model() -> str:    return _runtime["model"]


# ── Native recon modules (pure Python — no subprocess needed) ─────────────────
# These are the modules run by core/recon_native.py in parallel.
# No external tools required — everything runs via Python libraries.
NATIVE_MODULES = {
    "DNS":        "DNS enumeration — A, AAAA, MX, NS, TXT, CNAME, DMARC, SPF (dnspython)",
    "PORTSCAN":   "Async TCP port scan — top 30 ports (asyncio sockets)",
    "HEADERS":    "HTTP response headers + security header audit (requests)",
    "SSL":        "SSL/TLS certificate inspection — SANs, expiry, issuer (ssl module)",
    "SUBDOMAINS": "Passive subdomain discovery — crt.sh, AnubisDB, HackerTarget (requests)",
    "WHOIS":      "Domain WHOIS via RDAP API (requests)",
    "ROBOTS":     "robots.txt + sitemap.xml fetch (requests)",
    "CRAWL":      "Web crawl — links, JS files, emails, forms (requests + BeautifulSoup)",
    "WAYBACK":    "Wayback Machine — last 3 years of archived URLs (requests)",
    "VULNSCAN":   "14 parallel vuln checks — XSS, SQLi, LFI, CORS, .git, cookies, headers (requests)",
    "DIRSCAN":    "Async directory brute-force — built-in wordlist (aiohttp)",
}

# ── Python dependencies required ──────────────────────────────────────────────
REQUIRED_PACKAGES = [
    "requests",       # HTTP client
    "dnspython",      # DNS enumeration
    "beautifulsoup4", # HTML parsing for crawl
    "aiohttp",        # Async dir scan
    "tqdm",           # Progress bars
    "colorama",       # Colors on Windows
    "reportlab",      # PDF report generation
]
