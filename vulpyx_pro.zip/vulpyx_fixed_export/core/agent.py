"""
VULPYX – Agent
Every LLM call is a FRESH stateless session — no accumulated history.
Prompt files are loaded with a graceful fallback if missing.
"""
import os
from core.ollama_client import query_ollama
from core.banner        import thinking_dots, print_warn

_HERE        = os.path.dirname(os.path.abspath(__file__))
_PROMPTS_DIR = os.path.join(_HERE, "..", "prompts")

# ── Built-in fallback prompts (used if .txt files are missing) ─────────────────
_FALLBACKS = {
    "system": (
        "You are a professional penetration testing assistant on Kali Linux. "
        "Be precise, factual, and concise. Never invent vulnerabilities or tools."
    ),
    "analyze_output": (
        "Analyze the following penetration testing data:\n\n{context}\n\n"
        "Extract findings, open ports/services, and assess if a vulnerability is present. "
        "Rate confidence: LOW / MEDIUM / HIGH. "
        "Suggest one specific next Kali Linux command."
    ),
    "generate_methodology": (
        "Based on the following recon and context, suggest ONE specific "
        "penetration testing step with the exact Kali Linux command to run:\n\n{context}\n\n"
        "Output only: the command, its purpose, and what output to look for."
    ),
    "decision": (
        "Review this analysis and decide STOP or CONTINUE:\n\n{context}\n\n"
        "STOP only if a vulnerability is CONFIRMED with clear evidence. "
        "Format: DECISION: STOP/CONTINUE\nREASON: ...\nSTATUS: ..."
    ),
    "final_report": (
        "Write a professional penetration test report in markdown based on:\n\n{context}\n\n"
        "Include: Executive Summary, Scope, Findings (with severity), Recommendations."
    ),
}


def _load(name: str) -> str:
    """Load prompt from file; fall back to built-in if missing."""
    path = os.path.join(_PROMPTS_DIR, f"{name}.txt")
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if content:
                return content
    except FileNotFoundError:
        pass
    except Exception as e:
        print_warn(f"Could not read prompt '{name}.txt': {e}")
    # Use built-in fallback
    fallback = _FALLBACKS.get(name, f"Perform task: {name}\n\n{{context}}")
    print_warn(f"Prompt '{name}.txt' missing — using built-in fallback.")
    return fallback


def _trim(text: str, max_chars: int = 2000) -> str:
    if len(text) <= max_chars:
        return text
    return "[...trimmed...]\n" + text[-max_chars:]


def _build_prompt(system_name: str, task_name: str, context: str) -> str:
    system_prompt = _load(system_name)
    task_prompt   = _load(task_name).replace("{context}", context)
    return system_prompt + "\n\n" + task_prompt


# ── Public agent functions ─────────────────────────────────────────────────────

def analyze_recon(recon_results: dict, target: str) -> str:
    combined = f"TARGET: {target}\n\n"
    for tool, output in recon_results.items():
        combined += f"=== {tool.upper()} ===\n{output[:1500]}\n\n"
    prompt = _build_prompt("system", "analyze_output", combined)
    thinking_dots("Analyzing recon data", 2.0)
    return query_ollama(prompt)


def generate_methodology(context: str, step: int, recon_summary: str = "") -> str:
    if step == 1:
        enriched = (
            f"Step: 1 (FIRST STEP)\n\n"
            f"RECON SUMMARY:\n{_trim(recon_summary, 2000)}\n\n"
            f"Based on the recon above, suggest the FIRST penetration testing step."
        )
    else:
        enriched = (
            f"Step: {step}\n\n"
            f"LAST STEP FINDINGS:\n{_trim(context, 1500)}\n\n"
            f"Suggest the NEXT logical step. Do NOT repeat steps already done."
        )
    prompt = _build_prompt("system", "generate_methodology", enriched)
    thinking_dots(f"Generating Methodology Step {step}", 1.5)
    return query_ollama(prompt)


def analyze_step_output(method: str, user_output: str, recon_summary: str) -> str:
    combined = (
        f"SUGGESTED METHOD:\n{_trim(method, 500)}\n\n"
        f"USER OUTPUT:\n{_trim(user_output, 1500)}\n\n"
        f"RECON CONTEXT:\n{_trim(recon_summary, 500)}"
    )
    prompt = _build_prompt("system", "analyze_output", combined)
    thinking_dots("Analyzing tool output", 1.5)
    return query_ollama(prompt)


def decide_next(analysis: str) -> str:
    prompt = _build_prompt("system", "decision", _trim(analysis, 1500))
    thinking_dots("Running decision engine", 1.0)
    return query_ollama(prompt)


def generate_final_report(context: str) -> str:
    prompt = _build_prompt("system", "final_report", _trim(context, 2500))
    thinking_dots("Generating final report", 2.0)
    return query_ollama(prompt)


def vuln_confirmed(decision_text: str, analysis_text: str) -> bool:
    """
    Return True only when BOTH the decision says STOP and
    the analysis explicitly confirms a vulnerability.
    Case-insensitive, tolerant of LLM formatting variation.
    """
    d = decision_text.lower()
    a = analysis_text.lower()

    decision_says_stop = (
        "decision: stop" in d
        or ("decision" in d and "stop" in d.split("decision")[-1][:30])
        or (d.strip().startswith("stop"))
    )
    analysis_confirms = (
        ("vulnerability detected" in a and "yes" in a)
        or "confirmed" in a
        or ("vulnerability" in a and ("high" in a or "critical" in a))
    )
    return decision_says_stop and analysis_confirms
