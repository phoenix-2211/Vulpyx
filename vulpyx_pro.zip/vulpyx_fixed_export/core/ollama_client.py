"""
VULPYX – Ollama Client
Stateless LLM calls with streaming output, proper error handling,
automatic retry on transient failures, and no hanging.
"""
import json
import sys
import time
import requests
from core.config import OLLAMA_URL, get_model
from core.banner import MGN, CYN, GRN, YEL, RED, DIM, R

_STRICT_PREFIX = (
    "You are a precise penetration testing assistant on Kali Linux.\n"
    "RULES: Never invent CVEs or tool outputs. Only report what is in the input.\n"
    "If evidence is missing, say: 'Insufficient evidence'. Be concise.\n\n"
)

_MAX_CONTEXT_CHARS = 3000
_OLLAMA_TIMEOUT    = 300   # 5 minutes — enough for slow hardware
_MAX_RETRIES       = 2


def _is_ollama_running() -> bool:
    try:
        r = requests.get("http://localhost:11434/", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


def _trim_prompt(prompt: str) -> str:
    full = _STRICT_PREFIX + prompt
    if len(full) <= _MAX_CONTEXT_CHARS:
        return full
    tail = prompt[-(_MAX_CONTEXT_CHARS - len(_STRICT_PREFIX)):]
    return _STRICT_PREFIX + "[...trimmed for model capacity...]\n\n" + tail


def query_ollama(prompt: str, stream: bool = True) -> str:
    if not _is_ollama_running():
        return (
            f"{RED}[ERROR]{R} Ollama is not running.\n"
            "  Fix: run  ollama serve  in a separate terminal, then retry."
        )

    model        = get_model()
    final_prompt = _trim_prompt(prompt)

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            response = requests.post(
                OLLAMA_URL,
                json={
                    "model":   model,
                    "prompt":  final_prompt,
                    "stream":  stream,
                    "context": [],   # fresh session every call
                    "options": {
                        "temperature": 0.2,
                        "top_p":       0.9,
                        "num_predict": 512,
                        "num_ctx":     2048,
                    },
                },
                stream=stream,
                timeout=_OLLAMA_TIMEOUT,
            )

            if not stream:
                data = response.json()
                return data.get("response", "No response from model.")

            # Streaming
            collected = []
            tw = 60
            sys.stdout.write(f"\n  {MGN}┌{'─'*tw}┐{R}\n  {MGN}│{R} ")
            col_pos = 0
            for raw_line in response.iter_lines():
                if not raw_line:
                    continue
                try:
                    chunk = json.loads(raw_line)
                except (json.JSONDecodeError, ValueError):
                    continue
                token = chunk.get("response", "")
                collected.append(token)
                for ch in token:
                    if ch == "\n":
                        sys.stdout.write(f"\n  {MGN}│{R} ")
                        col_pos = 0
                    else:
                        # Wrap at terminal width
                        if col_pos >= tw - 2:
                            sys.stdout.write(f"\n  {MGN}│{R} ")
                            col_pos = 0
                        sys.stdout.write(ch)
                        col_pos += 1
                sys.stdout.flush()
                if chunk.get("done"):
                    break
            sys.stdout.write(f"\n  {MGN}└{'─'*tw}┘{R}\n")
            sys.stdout.flush()
            return "".join(collected)

        except requests.exceptions.Timeout:
            if attempt < _MAX_RETRIES:
                print(f"\n  {YEL}[!]{R}  Ollama timeout — retrying ({attempt}/{_MAX_RETRIES})...")
                time.sleep(2)
                continue
            return (
                f"{RED}[ERROR]{R} Ollama timed out after {_OLLAMA_TIMEOUT}s.\n"
                "  Try a lighter model: ollama pull qwen2.5-coder:1.5b"
            )
        except requests.exceptions.ConnectionError:
            return f"{RED}[ERROR]{R} Cannot connect to Ollama at {OLLAMA_URL}.\n  Run: ollama serve"
        except Exception as e:
            return f"{RED}[ERROR]{R} Unexpected error: {e}"

    return f"{RED}[ERROR]{R} All retries failed."
