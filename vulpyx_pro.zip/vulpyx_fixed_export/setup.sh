#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  VULPYX – Setup Script for Kali Linux
#  Run once after git clone:   chmod +x setup.sh && ./setup.sh
#
#  NOTE: No external recon tools needed — all recon is pure Python.
#  Only requires: Python 3.10+ libraries + Ollama + AI model
# ═══════════════════════════════════════════════════════════════════

set -e

RED='\033[1;31m'; YEL='\033[1;33m'; GRN='\033[1;32m'
CYN='\033[1;36m'; WHT='\033[1;37m'; DIM='\033[2m'; R='\033[0m'

print_ok()   { echo -e "  ${GRN}[✔]${R}  $1"; }
print_info() { echo -e "  ${CYN}[*]${R}  $1"; }
print_warn() { echo -e "  ${YEL}[!]${R}  $1"; }
print_err()  { echo -e "  ${RED}[✘]${R}  $1"; }
print_sep()  { echo -e "${CYN}$(printf '═%.0s' {1..70})${R}"; }

clear
echo ""
echo -e "${RED} __   ___   _ _     _______  __${R}"
echo -e "${RED} \ \ / / | | | |   |  __ \ \/ /${R}"
echo -e "${YEL}  \ V /| | | | |   | |__) \  / ${R}"
echo -e "${YEL}   > < | | | | |   |  ___//  \ ${R}"
echo -e "${CYN}  / . \| |_| | |___| |   / /\ \\${R}"
echo -e "${CYN} /_/ \_\\\\___/|_____|_|  /_/  \_\\\\${R}"
echo ""
echo -e "${CYN}       AI-Powered Penetration Testing Assistant${R}"
echo -e "${DIM}              Setup Script  v3.0${R}"
echo ""
print_sep

# ── Root check ─────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    print_warn "Not running as root – some installs may require sudo."
fi

# ── System update ──────────────────────────────────────────────────
print_sep
print_info "Updating package lists..."
sudo apt-get update -qq

# ── Python check ───────────────────────────────────────────────────
print_sep
print_info "Checking Python version..."
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
print_ok "Python $PY_VER found"

# ── Python dependencies ────────────────────────────────────────────
print_sep
print_info "Installing Python dependencies..."
print_info "Required: requests, dnspython, beautifulsoup4, aiohttp, tqdm, colorama, reportlab"

if python3 -c "import sys; sys.exit(0 if hasattr(sys, 'real_prefix') or sys.base_prefix != sys.prefix else 1)" 2>/dev/null; then
    pip3 install -r requirements.txt --quiet
else
    pip3 install -r requirements.txt --break-system-packages --quiet 2>&1 | grep -v "already satisfied" \
        || pip3 install -r requirements.txt --quiet
fi
print_ok "Python dependencies installed"

# ── Verify key packages ────────────────────────────────────────────
print_sep
print_info "Verifying Python packages..."
for pkg in requests dns bs4 aiohttp tqdm colorama reportlab; do
    if python3 -c "import $pkg" 2>/dev/null; then
        print_ok "$pkg available"
    else
        print_warn "$pkg missing — some modules will be skipped"
    fi
done

# ── Kali manual exploitation tools (optional but recommended) ──────
print_sep
print_info "Installing recommended manual exploitation tools..."
print_info "(These are used in methodology steps AFTER recon — not during recon)"
MANUAL_TOOLS=( sqlmap nikto ffuf gobuster hydra curl wfuzz )
for tool in "${MANUAL_TOOLS[@]}"; do
    if command -v "$tool" &>/dev/null; then
        print_ok "$tool already installed"
    else
        sudo apt-get install -y "$tool" -qq 2>/dev/null \
            && print_ok "$tool installed" \
            || print_warn "$tool could not be installed (skipping)"
    fi
done

# ── Ollama ─────────────────────────────────────────────────────────
print_sep
print_info "Checking Ollama..."

if ! command -v ollama &>/dev/null; then
    print_info "Ollama not found. Installing..."
    curl -fsSL https://ollama.com/install.sh | sh
    print_ok "Ollama installed"
else
    print_ok "Ollama already installed"
fi

# Start Ollama if not running
if ! pgrep -x "ollama" &>/dev/null; then
    print_info "Starting Ollama service..."
    ollama serve &>/dev/null &
    OLLAMA_PID=$!
    sleep 4
    print_ok "Ollama service started (PID: $OLLAMA_PID)"
else
    print_ok "Ollama service already running"
fi

# ── Pull AI Model ──────────────────────────────────────────────────
print_sep
print_info "Pulling AI model: qwen2.5-coder:1.5b"
print_info "This is a ~1 GB download. Please wait..."
echo ""

ollama pull qwen2.5-coder:1.5b &>/tmp/ollama_pull.log &
PULL_PID=$!

spinner=( '⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏' )
i=0
while kill -0 "$PULL_PID" 2>/dev/null; do
    printf "\r  ${CYN}[${spinner[$i]}]${R}  Downloading model..."
    i=$(( (i + 1) % ${#spinner[@]} ))
    sleep 0.1
done
printf "\r                                        \r"

wait "$PULL_PID"
PULL_EXIT=$?

if [[ $PULL_EXIT -eq 0 ]]; then
    print_ok "Model ready: qwen2.5-coder:1.5b"
else
    print_err "Model pull failed. Check /tmp/ollama_pull.log"
    exit 1
fi

# ── Permissions ────────────────────────────────────────────────────
print_sep
chmod +x vulpyx.py
print_ok "vulpyx.py marked as executable"

# ── Final message ──────────────────────────────────────────────────
print_sep
echo ""
echo -e "  ${GRN}✔  VULPYX SETUP COMPLETE${R}"
echo ""
echo -e "  ${WHT}What was installed:${R}"
echo -e "  ${CYN}  • Python libs: requests, dnspython, beautifulsoup4, aiohttp, tqdm, reportlab${R}"
echo -e "  ${CYN}  • Ollama + qwen2.5-coder:1.5b model${R}"
echo -e "  ${CYN}  • Manual tools: sqlmap, nikto, ffuf, gobuster, hydra, curl, wfuzz${R}"
echo ""
echo -e "  ${WHT}Recon modules (pure Python — no extra tools needed):${R}"
echo -e "  ${DIM}  DNS · PortScan · Headers · SSL · Subdomains · WHOIS${R}"
echo -e "  ${DIM}  Robots · Crawl · Wayback · VulnScan · DirScan${R}"
echo ""
echo -e "  ${WHT}To run VULPYX:${R}"
echo -e "  ${CYN}  1. ollama serve   (in a separate terminal)${R}"
echo -e "  ${CYN}  2. python3 vulpyx.py${R}"
echo ""
print_sep
echo ""
