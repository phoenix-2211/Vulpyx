
  import asyncio
  import ssl
  import aiohttp
  import socket
  import dns.resolver
  from urllib.parse import urljoin, urlparse
  from bs4 import BeautifulSoup
  import ssl
  import json
  import os
  import re
  from datetime import datetime
  from concurrent.futures import ThreadPoolExecutor
  from typing import Dict, List, Optional, Any
  import aiofiles
  import certifi

  class ReconNative:
      """
      Pure Python reconnaissance engine running all modules in parallel threads.
      Ollama analysis runs AFTER all scanning is complete.
      """

      def __init__(self, target: str, threads: int = 10):
          self.target = target
          self.threads = threads
          self.results = {}
          self.errors = []
          self.session = None

      async def initialize(self):
          """Initialize aiohttp session with proper SSL and timeouts"""
          connector = aiohttp.TCPConnector(limit=50, ttl_dns_cache=300)
          timeout = aiohttp.ClientTimeout(total=30, connect=10, sock_read=30)
          headers = {
              'User-Agent': 'Omnisci3nt Recon v2.0 (Pure Python)',
              'Accept': 'text/html,application/xml',
              'Accept-Language': 'en-US,en;q=0.9'
          }
          self.session = aiohttp.ClientSession(
              connector=connector,
              timeout=timeout,
              headers=headers
          )
          return self.session

      async def close(self):
          """Clean up resources"""
          if self.session:
              await self.session.close()

      async def run_all_scans(self):
          """Run all 11 modules in parallel threads"""
          executor = ThreadPoolExecutor(max_workers=self.threads)

          # Start all async tasks with thread pool
          async def wrapper(task):
              await asyncio.get_event_loop().run_in_executor(
                  executor, task.__func__, task
              )

          # Module list - 11 recon modules
          modules = [
              ('dns_scan', self.dns_scan),
              ('port_scan', self.port_scan),
              ('headers', self.headers_scan),
              ('ssl_check', self.ssl_inspect),
              ('subdomain', self.subdomain_discovery),
              ('whois', self.whois_lookup),
              ('robots', self.robots_txt),
              ('crawl', self.web_crawl),
              ('wayback', self.wayback_machine),
              ('vuln', self.vuln_scan),
              ('dirs', self.dir_scan),
          ]

          # Run all modules concurrently
          tasks = [
              asyncio.create_task(wrapper(module[1]))
              for module in modules
          ]

          # Wait for completion
          results = await asyncio.gather(*tasks, return_exceptions=True)

          for (name, task), result in zip(modules, results):
              if isinstance(result, Exception):
                  self.errors.append(f"{name}: {result}")
              else:
                  self.results[name] = result

          executor.shutdown(wait=True)
          return self.results

      async def dns_scan(self):
          """A/AAAA/MX/NS/TXT/CNAME/DMARC/SPF enumeration using dns.resolver"""
          records = {
              'A': [], 'AAAA': [], 'MX': [], 'NS': [],
              'TXT': [], 'CNAME': [], 'DMARC': [], 'SPF': []
          }

          record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME']
          for rtype in record_types:
              try:
                  answers = await asyncio.get_event_loop().run_in_executor(
                      None, lambda t=rtype: asyncio.run(
                          dns.resolver.resolve(self.target, t)
                      )
                  )
                  records[rtype] = [str(a) for a in answers]
              except Exception as e:
                  self.errors.append(f"DNS {rtype}: {e}")

          # Check DMARC and SPF
          try:
              dmarc = await asyncio.get_event_loop().run_in_executor(
                  None, lambda: asyncio.run(
                      dns.resolver.resolve(f'{self.target}.._domainkey', 'TXT')
                  )
              )
              records['DMARC'] = [str(a) for a in dmarc] if dmarc else []
          except:
              records['DMARC'] = []

          try:
              spf = await asyncio.get_event_loop().run_in_executor(
                  None, lambda: asyncio.run(
                      dns.resolver.resolve(f'{self.target}.', 'TXT')
                  )
              )
              for txt in spf:
                  if 'v=spf1' in str(txt):
                      records['SPF'] = [str(txt)]
          except:
              records['SPF'] = []

          return {
              'target': self.target,
              'timestamp': datetime.now().isoformat(),
              'records': records,
              'total_records': sum(len(v) for v in records.values())
          }

      async def port_scan(self):
          """Async socket scan for top 30 ports"""
          ports = [
              21, 22, 23, 25, 53, 80, 443, 445, 135, 137,
              138, 139, 143, 445, 446, 447, 993, 995, 1433,
              1434, 3306, 3389, 5432, 5900, 8080, 8443,
              8000, 9200, 27017
          ]

          results = {}
          for port in ports:
              try:
                  sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                  sock.settimeout(0.5)
                  result = sock.connect_ex((self.target, port))
                  if result == 0:
                      results[port] = {
                          'open': True,
                          'service_guess': self._guess_service(port)
                      }
                  else:
                      results[port] = {'open': False}
                  sock.close()
              except Exception as e:
                  results[port] = {'error': str(e)}

          return {
              'target': self.target,
              'timestamp': datetime.now().isoformat(),
              'open_ports': list(results.keys()),
              'scan_results': results
          }

      async def headers_scan(self):
          """HTTP headers + security header audit"""
          try:
              async with self.session.get(self.target) as response:
                  headers = dict(response.headers)
                  return {
                      'target': self.target,
                      'status': response.status,
                      'title': response.history[-1].url if response.history else self.target,
                      'headers': headers,
                      'security_headers': {
                          'X-Frame-Options': headers.get('X-Frame-Options'),
                          'X-Content-Type-Options': headers.get('X-Content-Type-Options'),
                          'Content-Security-Policy': headers.get('Content-Security-Policy'),
                          'Strict-Transport-Security': headers.get('Strict-Transport-Security'),
                      },
                      'headers_length': len(headers)
                  }
          except Exception as e:
              return {'error': str(e)}

      async def ssl_inspect(self):
          """SSL/TLS inspection"""
          try:
              context = ssl.create_default_context()
              context.check_hostname = True
              context.verify_mode = ssl.CERT_REQUIRED

              loop = asyncio.get_event_loop()
              result = await loop.run_in_executor(
                  None, lambda: asyncio.run(
                      self._ssl_check(self.target, context)
                  )
              )
              return result
          except Exception as e:
              return {'error': str(e)}

      async def _ssl_check(self, target: str, context):
          """SSL certificate analysis"""
          try:
              from cryptography import x509
              from cryptography.hazmat.primitives import serialization
              import ssl

              loop = asyncio.get_event_loop()

              sock = socket.create_connection((target, 443))
              sock = loop.run_until_complete(
                  socket.create_connection((target, 443))
              )
              conn = context.wrap_socket(sock, server_hostname=target)
              cert = conn.getpeercert()
              conn.close()

              cert_chain = []
              for cert in ssl.DERCertificate.get_chain():
                  cert_chain.append({
                      'issuer': cert.get_issuer().get_common_name(),
                      'subject': cert.get_subject().get_common_name(),
                      'not_before': cert.get_notBefore(),
                      'not_after': cert.get_notAfter()
                  })

              return {
                  'valid': True,
                  'issuer': cert.get_issuer().get_common_name(),
                  'subject': cert.get_subject().get_common_name(),
                  'valid_from': cert.get_notBefore(),
                  'valid_until': cert.get_notAfter(),
                  'days_remaining': (
                      datetime.fromtimestamp(
                          int(cert.get_notAfter()[:10])
                      ).date() - datetime.now().date()
                  ).days,
                  'cert_chain_length': len(cert_chain),
                  'signature_algorithm': cert.get_signature_algorithm()
              }
          except Exception as e:
              return {'error': str(e)}

      async def subdomain_discovery(self):
          """DNS subdomain brute-force"""
          subdomains = ['www', 'mail', 'ftp', 'admin', 'test',
                        'dev', 'staging', 'api', 'app', 'blog',
                        'shop', 'store', 'cdn', 'news', 'support']

          results = {}
          for sub in subdomains:
              try:
                  result = await asyncio.get_event_loop().run_in_executor(
                      None, lambda s=sub, t=self.target: asyncio.run(
                          dns.resolver.resolve(f'{s}.{t}', 'A')
                      )
                  )
                  results[sub] = result is not None
              except:
                  results[sub] = False

          return {
              'target': self.target,
              'subdomains': [s for s in results if results[s]],
              'total_discovered': len([s for s in results if results[s]])
          }

      async def whois_lookup(self):
          """Whois data collection (using python-whois or manual lookup)"""
          try:
              import whois
              # Fallback without external whois library
              whois_data = {
                  'domain': self.target,
                  'registration_date': None,
                  'expiration_date': None,
                  'registrar': 'Unknown (requires external lookup)'
              }
              return whois_data
          except ImportError:
              return {'error': 'whois library not found'}

      async def robots_txt(self):
          """robots.txt and sitemap discovery"""
          targets = [
              self.target,
              f"{self.target}/sitemap.xml",
              f"{self.target}/sitemap_index.xml"
          ]

          results = {
              'robots.txt': None,
              'sitemaps': []
          }

          try:
              async with self.session.get(self.target + '/robots.txt') as resp:
                  if resp.status == 200:
                      results['robots.txt'] = await resp.text()
          except:
              results['robots.txt'] = 'Not found'

          try:
              async with self.session.get('https://web.archive.org/web/2024/*'
                                         f'/robots.txt/{self.target}') as resp:
                  if resp.status == 200:
                      results['wayback_robots'] = await resp.text()
          except:
              results['wayback_robots'] = 'N/A'

          return results

      async def web_crawl(self):
          """Recursive web crawling with rate limiting"""
          visited = set()
          queue = [self.target]
          links = []

          async def crawl_page(url):
              try:
                  async with self.session.get(url) as resp:
                      if resp.status == 200:
                          html = await resp.text()
                          soup = BeautifulSoup(html, 'html.parser')

                          # Collect links
                          for a in soup.find_all('a', href=True):
                              href = a['href']
                              if href.startswith('http'):
                                  links.append(href)
                                  if href not in visited:
                                      visited.add(href)
                                      queue.append(href)

                          # Extract meta data
                          meta = {
                              'title': soup.title.string if soup.title else None,
                              'description': soup.find('meta', attrs={'name': 'description'})['content']
                              if soup.find('meta', attrs={'name': 'description'}) else None
                          }
                          return {'url': url, 'title': meta.get('title'), 'meta': meta}
              except Exception as e:
                  return {'error': str(e)}

          while queue:
              url = queue.pop(0)
              if len(visited) > 1000:  # Limit crawl depth
                  break

              try:
                  await crawl_page(url)
              except:
                  continue

          return {
              'total_links': len(links),
              'visited_pages': len(visited),
              'sample_links': links[:10]
          }

      async def vuln_scan(self):
          """Basic vulnerability scanning (directory enumeration, common patterns)"""
          common_paths = [
              '/wp-admin', '/wp-login', '/admin', '/phpmyadmin',
              '/dashboard', '/login', '/api/v1', '/api/v2',
              '/.git', '/.env', '/config'
          ]

          results = []
          for path in common_paths:
              try:
                  url = f"{self.target}{path}"
                  async with self.session.head(url, allow_redirects=True) as resp:
                      if resp.status in [200, 301, 302]:
                          results.append({
                              'path': path,
                              'status': resp.status,
                              'method': 'HEAD'
                          })
              except:
                  continue

          return {
              'common_paths_found': results,
              'total_potential_issues': len(results)
          }

      async def dir_scan(self):
          """Dirb-style directory enumeration"""
          common_dirs = [
              'admin', 'login', 'login.html', 'administrator',
              'phpmyadmin', 'wp-admin', 'dashboard', 'panel',
              'files', 'uploads', 'backup', 'db', 'test'
          ]

          found = []
          for dir_path in common_dirs:
              try:
                  async with self.session.get(
                      f"{self.target}/{dir_path}",
                      allow_redirects=False
                  ) as resp:
                      if resp.status in [200, 301, 302]:
                          found.append(dir_path)
              except:
                  continue

          return {
              'found_directories': found,
              'total': len(found)
          }

      async def wayback_machine(self):
          """Web archive search"""
          try:
              import aiohttp

              wayback_url = f"https://web.archive.org/cdx/search/cdx?url={self.target}/"

              async with aiohttp.ClientSession() as session:
                  async with session.get(wayback_url) as resp:
                      if resp.status == 200:
                          text = await resp.text()
                          entries = text.split()
                          return {'wayback_available': len(entries) > 0, 'total_archives': len(entries)}
          except:
              pass

          return {'wayback_available': False}

      async def generate_report(self):
          """Generate final report after all scans"""
          report = {
              'target': self.target,
              'scan_timestamp': datetime.now().isoformat(),
              'modules_completed': len(self.results),
              'errors': self.errors,
              'summary': {
                  'open_ports': sum(1 for s in self.results.values() if isinstance(s, dict) and s.get('open') == True),
                  'ssl_status': 'Invalid' if self.results.get('ssl', {}).get('valid') == False else 'Valid',
                  'open_subdomains': len(self.results.get('subdomains', {}).get('subdomains', [])),
                  'discovered_dirs': len(self.results.get('directories', [])),
                  'vulnerabilities': len(self.results.get('vulnerabilities', []))
              }
          }